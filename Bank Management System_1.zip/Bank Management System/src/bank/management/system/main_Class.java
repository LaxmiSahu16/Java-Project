package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class main_Class extends JFrame implements ActionListener {
    JButton b1,b2,b3,b4,b5,b6,b7;
    String pin;

    main_Class(String pin){
        this.pin = pin;
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atmpin.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0,0,1550,830);
        add(l3);

        JLabel label = new JLabel("Please Select Your Transaction");
        label.setBounds(600,80,700,35);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("System",Font.BOLD,28));
        l3.add(label);

        b1 = new JButton("DEPOSIT");
        b1.setForeground(Color.WHITE);
        b1.setBackground(Color.DARK_GRAY);
        b1.setBounds(670,360,110,35);
        b1.addActionListener(this);
        l3.add(b1);

        b2 = new JButton("CASH WITHDRWL");
        b2.setForeground(Color.WHITE);
        b2.setBackground(Color.DARK_GRAY);
        b2.setBounds(358,395,140,35);
        b2.addActionListener(this);
        l3.add(b2);

        b3 = new JButton("FAST CASH");
        b3.setForeground(Color.WHITE);
        b3.setBackground(Color.DARK_GRAY);
        b3.setBounds(365,435,130,35);
        b3.addActionListener(this);
        l3.add(b3);

        b4 = new JButton("MINI STATEMENT");
        b4.setForeground(Color.WHITE);
        b4.setBackground(Color.DARK_GRAY);
        b4.setBounds(365,475,140,35);
        b4.addActionListener(this);
        l3.add(b4);

        b5 = new JButton("PIN CHANGE");
        b5.setForeground(Color.WHITE);
        b5.setBackground(Color.DARK_GRAY);
        b5.setBounds(1000,395,110,35);
        b5.addActionListener(this);
        l3.add(b5);

        b6 = new JButton("BALANCE ENQUIY");
        b6.setForeground(Color.WHITE);
        b6.setBackground(Color.DARK_GRAY);
        b6.setBounds(1000,435,145,35);
        b6.addActionListener(this);
        l3.add(b6);


        b7 = new JButton("EXIT");
        b7.setForeground(Color.WHITE);
        b7.setBackground(Color.DARK_GRAY);
        b7.setBounds(1000,475,100,35);
        b7.addActionListener(this);
        l3.add(b7);



        setLayout(null);
        setSize(1550,1080);
        setLocation(0,0);
        setVisible(true);

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==b1){
            new Deposit(pin);
            setVisible(false);
        }else if(e.getSource()==b7){
            System.exit(0);
        }else if (e.getSource()==b2) {
            new Withdrawl(pin);
            setVisible(false);
        }else if(e.getSource()==b6){
            setVisible(false);
            new BalanceEnquiry(pin);
        }else if(e.getSource()==b3) {
            new FastCash(pin);
            setVisible(false);
        }else if (e.getSource()==b5){
            new Pin(pin);
            setVisible(false);
        }else if(e.getSource()==b4){
            new mini(pin);
        }
    }

    public static void main(String[] args) {
        new main_Class("");

    }
}
