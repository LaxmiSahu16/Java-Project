package bank.management.system;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Pin extends JFrame implements ActionListener {
    JButton b1,b2;
    JPasswordField p1,p2;
    String pin;
    Pin(String pin) {
        this.pin = pin;

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/atmpin.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1550,830,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel l3 = new JLabel(i3);
        l3.setBounds(0,0,1550,830);
        add(l3);

        JLabel label = new JLabel("CHANGE NEW PIN");
        label.setBounds(600,80,700,35);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("System",Font.BOLD,28));
        l3.add(label);

        JLabel label2 = new JLabel("NEW PIN:");
        label2.setFont(new Font("System",Font.BOLD,22));
        label2.setBounds(360,400,200,20);
        l3.add(label2);

        p1 = new JPasswordField();
        p1.setBackground(Color.DARK_GRAY);
        p1.setForeground(Color.WHITE);
        p1.setBounds(340,430,150,30);
        p1.setFont(new Font("Raleway",Font.BOLD,22));
        l3.add(p1);

        JLabel label3 = new JLabel("Re- Enter NEW PIN:");
        label3.setFont(new Font("System",Font.BOLD,20));
        label3.setBounds(310,480,250,20);
        l3.add(label3);


        p2 = new JPasswordField();
        p2.setBackground(Color.DARK_GRAY);
        p2.setForeground(Color.WHITE);
        p2.setBounds(310,505,180,30);
        p2.setFont(new Font("Raleway",Font.BOLD,22));
        l3.add(p2);


        b1 = new JButton("CHANGE");
        b1.setBounds(600,359,150,35);
        b1.setBackground(Color.DARK_GRAY);
        b1.setForeground(Color.WHITE);
        b1.addActionListener(this);
        l3.add(b1);

        b2 = new JButton("BACK");
        b2.setBounds(770,359,150,35);
        b2.setBackground(Color.DARK_GRAY);
        b2.setForeground(Color.WHITE);
        b2.addActionListener(this);
        l3.add(b2);

        setSize(1550,1080);
        setLayout(null);
        setLocation(0,0);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        try{

            String pin1 = p1.getText();
            String pin2 = p2.getText();

            if(!pin1.equals(pin2)){
                JOptionPane.showMessageDialog(null,"Entered PIN does not match");
                return;
            }

            if(e.getSource()==b1){
                if(p1.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"Enter New PIN ");
                    return;
                }
                if(p2.getText().equals("")){
                    JOptionPane.showMessageDialog(null,"RE- Enter New PIN ");
                    return;
                }
                Con c = new Con();
                String q1 = "update bank set pin ='"+pin1+"' where pin = '"+pin+"'";
                String q2 = "update login set pin ='"+pin1+"' where pin = '"+pin+"'";
                String q3 = "update signupthree set pin ='"+pin1+"' where pin = '"+pin+"'";

                c.statement.executeUpdate(q1);
                c.statement.executeUpdate(q2);
                c.statement.executeUpdate(q3);

                JOptionPane.showMessageDialog(null,"PIN changed successfully");
                setVisible(false);
                new main_Class(pin);

            }else if  (e.getSource()==b2){
                new main_Class(pin);
                setVisible(false);
            }



        }catch(Exception E){
            E.printStackTrace();
        }

    }

    public static void main(String[] args) {
        new Pin("");
    }
}
